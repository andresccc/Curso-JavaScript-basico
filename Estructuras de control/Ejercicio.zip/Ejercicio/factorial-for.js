// Este archivo debe calcular el factorial de 10 utilizando un solo bucle for
let factorial = 1;

for (let i = 1; i < 11; i++) {
  factorial *= i;
}
console.log(factorial);
